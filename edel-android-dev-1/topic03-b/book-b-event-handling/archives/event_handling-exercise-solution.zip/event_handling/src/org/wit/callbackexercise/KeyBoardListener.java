package org.wit.callbackexercise;

import org.wit.callback.TextWatcher;

public interface KeyBoardListener extends TextWatcher
{
  void onKeyBoardInput();
}
