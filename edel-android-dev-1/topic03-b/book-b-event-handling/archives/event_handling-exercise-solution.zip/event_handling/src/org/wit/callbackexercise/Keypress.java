package org.wit.callbackexercise;

import org.wit.callback.TextView;

public class Keypress extends TextView
{
  public void addKeyBoardListener(KeyBoardListener listener)
  {
    // Save the event object for later use.
    super.textwatcher = listener;
  }
  
  // This method will be invoked repeatedly in an event loop
  @Override
  public void doWork()
  {
    // Check the predicate, which is set elsewhere.
    if (somethingHappened)
    {
      // Signal the event by invoking the interface's method.
      ((KeyBoardListener)textwatcher).onKeyBoardInput();
      textwatcher.onTextChanged("Finally - you called back");
      somethingHappened = false;
    }
  }
}