package controllers;

import java.util.List;
import java.util.Random;

import models.Residence;
import play.Logger;
import play.mvc.Controller;
import utils.JsonParsers;

import com.google.gson.JsonElement;

public class MyRentServiceAPI extends Controller
{
  public static void residences()
  {
    List<Residence> residences = Residence.findAll();
    renderJSON(JsonParsers.residence2Json(residences));
  }
  
  public static void residence(Long id)
  {
    Residence residence = Residence.findById(id);  
    if (residence == null)
    {
      notFound();
    }
    else
    {
      renderJSON(JsonParsers.residence2Json(residence));
    }
  }
  
  public static void createResidence(JsonElement body)
  {
    Residence residence = JsonParsers.json2Residence(body.toString());
    residence.save();
    renderJSON(JsonParsers.residence2Json(residence));
  }
  
  public static void deleteResidence(String id)
  {
    Residence residence = Residence.findById(id);
    if (residence == null)
    {
      notFound();
    }
    else
    {
      residence.delete();
      renderText("success");
    }
  }
  
  public static void deleteAllResidences()
  {
    Residence.deleteAll();
    renderText("success");
  }  
}
