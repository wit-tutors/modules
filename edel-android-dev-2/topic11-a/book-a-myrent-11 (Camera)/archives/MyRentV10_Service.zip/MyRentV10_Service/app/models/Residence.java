package models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import play.db.jpa.GenericModel;

@Entity
public class Residence extends GenericModel
{
  @Id
  public String  uuid           ;
  public String  geolocation    ;
  public String  date           ;
  public boolean rented         ;
  public String  tenant         ;
  public double  zoom           ;
  public String  photoFileName  ;

}
