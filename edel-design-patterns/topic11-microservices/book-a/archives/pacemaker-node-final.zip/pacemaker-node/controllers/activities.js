/**
 * Created by tomwalsh on 18/04/2014.
 */
var router = require('express').Router();

router.get('/', function(req, res) {
  var activitiesDb = req.app.get('activitiesDb');
  var uId = req.app.get('activityUserId');

  activitiesDb.readAll (uId, function (data) {
    res.send(data);
  });
});

router.post('/', function(req, res) {
  var activitiesDb = req.app.get('activitiesDb');
  var uId = req.app.get('activityUserId');

  activitiesDb.create(uId, req.body, function (data) {
    res.send(data);
  });
});

router.get('/:activityId', function(req, res) {
  var activitiesDb = req.app.get('activitiesDb');
  var uId = req.app.get('activityUserId');

  activitiesDb.read (uId, req.params.activityId, function (data) {
    res.send(data);
  });
});

router.put('/:activityId', function(req, res) {
  var activitiesDb = req.app.get('activitiesDb');
  var uId = req.app.get('activityUserId');

  activitiesDb.update (uId, req.params.activityId, req.body, function (data) {
    res.send(data);
  });
});

router.delete('/:activityId', function(req, res) {
  var activitiesDb = req.app.get('activitiesDb');
  var uId = req.app.get('activityUserId');

  activitiesDb.delete (uId, req.params.activityId, function (data) {
    res.send(data);
  });
});

module.exports = router;