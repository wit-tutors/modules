/**
 * Created by tomwalsh on 25/04/2014.
 */

module.exports = [
  {
    email: 'homer@simpson.com',
    firstName: 'homer',
    lastName: 'simpson',
    password: 'secret'
  },
  {
    email: 'bart@simpson.com',
    firstName: 'bart',
    lastName: 'simpson',
    password: 'secret'
  },
  {
    email: 'marge@simpson.com',
    firstName: 'marge',
    lastName: 'simpson',
    password: 'secret'
  },
  {
    email: 'lisae@simpson.com',
    firstName: 'lisa',
    lastName: 'simpson',
    password: 'secret'
  }
]