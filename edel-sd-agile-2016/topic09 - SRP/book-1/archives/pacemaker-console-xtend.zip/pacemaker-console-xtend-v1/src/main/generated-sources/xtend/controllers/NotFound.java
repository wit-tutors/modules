package controllers;

import controllers.Response;

@SuppressWarnings("all")
public class NotFound extends Response {
  public NotFound(final String response) {
    super("not found\n");
  }
}
