package controllers;

import controllers.Response;

@SuppressWarnings("all")
public class Ok extends Response {
  public Ok(final String response) {
    super(("ok\n" + response));
  }
}
