package controllers;

import com.google.common.base.Objects;
import controllers.NotFound;
import controllers.Ok;
import controllers.PacemakerAPI;
import controllers.Response;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import models.Activity;
import models.User;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import parsers.Parser;

@SuppressWarnings("all")
public class PacemakerService {
  private PacemakerAPI pacemaker;
  
  private Parser parser;
  
  public PacemakerService(final PacemakerAPI pacemaker, final Parser parser) {
    this.pacemaker = pacemaker;
    this.parser = parser;
  }
  
  public Ok createUser(final String firstname, final String lastname, final String email, final String password) {
    Ok _xblockexpression = null;
    {
      final Long id = this.pacemaker.createUser(firstname, lastname, email, password);
      User _user = this.pacemaker.getUser(id);
      String _renderUser = this.parser.renderUser(_user);
      _xblockexpression = new Ok(_renderUser);
    }
    return _xblockexpression;
  }
  
  public Response getUser(final Long id) {
    Response _xblockexpression = null;
    {
      final User user = this.pacemaker.getUser(id);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, user));
      if (_notEquals) {
        String _renderUser = this.parser.renderUser(user);
        _xifexpression = new Ok(_renderUser);
      } else {
        _xifexpression = new NotFound("");
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  public Response getUser(final String email) {
    Response _xblockexpression = null;
    {
      final User user = this.pacemaker.getUser(email);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, user));
      if (_notEquals) {
        Long _id = user.getId();
        _xifexpression = this.getUser(_id);
      } else {
        _xifexpression = new NotFound("");
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  public Ok getUsers() {
    Collection<User> _users = this.pacemaker.getUsers();
    String _renderUsers = this.parser.renderUsers(_users);
    return new Ok(_renderUsers);
  }
  
  public Response deleteUser(final Long id) {
    Response _xblockexpression = null;
    {
      final User user = this.pacemaker.getUser(id);
      Long _id = null;
      if (user!=null) {
        _id=user.getId();
      }
      this.pacemaker.deleteUser(_id);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, user));
      if (_notEquals) {
        _xifexpression = new Ok("");
      } else {
        _xifexpression = new NotFound("");
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  public Response createActivity(final Long id, final String type, final String location, final double distance, final String dateStr, final String durationStr) {
    Response _xifexpression = null;
    User _user = this.pacemaker.getUser(id);
    boolean _notEquals = (!Objects.equal(null, _user));
    if (_notEquals) {
      Ok _xblockexpression = null;
      {
        this.pacemaker.createActivity(id, type, location, distance, dateStr, durationStr);
        _xblockexpression = new Ok("");
      }
      _xifexpression = _xblockexpression;
    } else {
      _xifexpression = new NotFound("");
    }
    return _xifexpression;
  }
  
  public Response getActivities(final Long id) {
    Response _xblockexpression = null;
    {
      final User user = this.pacemaker.getUser(id);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, user));
      if (_notEquals) {
        Map<Long, Activity> _activities = user.getActivities();
        Collection<Activity> _values = _activities.values();
        String _renderActivities = this.parser.renderActivities(_values);
        _xifexpression = new Ok(_renderActivities);
      } else {
        _xifexpression = new NotFound("");
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  public Response addLocation(final Long id, final float latitude, final float longitude) {
    Response _xblockexpression = null;
    {
      final Activity activity = this.pacemaker.getActivity(id);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, activity));
      if (_notEquals) {
        Ok _xblockexpression_1 = null;
        {
          this.pacemaker.addLocation(id, latitude, longitude);
          _xblockexpression_1 = new Ok("");
        }
        _xifexpression = _xblockexpression_1;
      } else {
        _xifexpression = new NotFound("");
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  public Ok listActivities(final Long id, final String sortBy) {
    User _user = this.pacemaker.getUser(id);
    Map<Long, Activity> _activities = _user.getActivities();
    Collection<Activity> activities = _activities.values();
    List<Activity> _switchResult = null;
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(sortBy, "type")) {
        _matched=true;
        final Function1<Activity, String> _function = new Function1<Activity, String>() {
          @Override
          public String apply(final Activity it) {
            return it.getType();
          }
        };
        _switchResult = IterableExtensions.<Activity, String>sortBy(activities, _function);
      }
    }
    if (!_matched) {
      if (Objects.equal(sortBy, "location")) {
        _matched=true;
        final Function1<Activity, String> _function_1 = new Function1<Activity, String>() {
          @Override
          public String apply(final Activity it) {
            return it.getLocation();
          }
        };
        _switchResult = IterableExtensions.<Activity, String>sortBy(activities, _function_1);
      }
    }
    if (!_matched) {
      if (Objects.equal(sortBy, "distance")) {
        _matched=true;
        final Function1<Activity, Double> _function_2 = new Function1<Activity, Double>() {
          @Override
          public Double apply(final Activity it) {
            return Double.valueOf(it.getDistance());
          }
        };
        _switchResult = IterableExtensions.<Activity, Double>sortBy(activities, _function_2);
      }
    }
    if (!_matched) {
      if (Objects.equal(sortBy, "date")) {
        _matched=true;
        final Function1<Activity, DateTime> _function_3 = new Function1<Activity, DateTime>() {
          @Override
          public DateTime apply(final Activity it) {
            return it.getStarttime();
          }
        };
        _switchResult = IterableExtensions.<Activity, DateTime>sortBy(activities, _function_3);
      }
    }
    if (!_matched) {
      if (Objects.equal(sortBy, "duration")) {
        _matched=true;
        final Function1<Activity, Duration> _function_4 = new Function1<Activity, Duration>() {
          @Override
          public Duration apply(final Activity it) {
            return it.getDuration();
          }
        };
        _switchResult = IterableExtensions.<Activity, Duration>sortBy(activities, _function_4);
      }
    }
    final List<Activity> report = _switchResult;
    String _renderActivities = this.parser.renderActivities(report);
    return new Ok(_renderActivities);
  }
}
