package controllers;

@SuppressWarnings("all")
public abstract class Response {
  private String response;
  
  public Response(final String response) {
    this.response = response;
  }
  
  @Override
  public String toString() {
    return this.response;
  }
}
