package models;

import java.util.ArrayList;
import java.util.List;
import models.Location;
import org.eclipse.xtend.lib.Data;
import org.eclipse.xtend.lib.Property;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringHelper;
import org.joda.time.DateTime;
import org.joda.time.Duration;

@Data
@SuppressWarnings("all")
public class Activity {
  private final Long _id;
  
  private final String _type;
  
  private final String _location;
  
  private final double _distance;
  
  private final DateTime _starttime;
  
  private final Duration _duration;
  
  @Property
  private final List<Location> __route = new ArrayList<Location>();
  
  public Activity(final Long id, final String type, final String location, final double distance, final DateTime starttime, final Duration duration) {
    super();
    this._id = id;
    this._type = type;
    this._location = location;
    this._distance = distance;
    this._starttime = starttime;
    this._duration = duration;
  }
  
  @Override
  @Pure
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this._id== null) ? 0 : this._id.hashCode());
    result = prime * result + ((this._type== null) ? 0 : this._type.hashCode());
    result = prime * result + ((this._location== null) ? 0 : this._location.hashCode());
    result = prime * result + (int) (Double.doubleToLongBits(this._distance) ^ (Double.doubleToLongBits(this._distance) >>> 32));
    result = prime * result + ((this._starttime== null) ? 0 : this._starttime.hashCode());
    result = prime * result + ((this._duration== null) ? 0 : this._duration.hashCode());
    result = prime * result + ((this.__route== null) ? 0 : this.__route.hashCode());
    return result;
  }
  
  @Override
  @Pure
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Activity other = (Activity) obj;
    if (this._id == null) {
      if (other._id != null)
        return false;
    } else if (!this._id.equals(other._id))
      return false;
    if (this._type == null) {
      if (other._type != null)
        return false;
    } else if (!this._type.equals(other._type))
      return false;
    if (this._location == null) {
      if (other._location != null)
        return false;
    } else if (!this._location.equals(other._location))
      return false;
    if (Double.doubleToLongBits(other._distance) != Double.doubleToLongBits(this._distance))
      return false; 
    if (this._starttime == null) {
      if (other._starttime != null)
        return false;
    } else if (!this._starttime.equals(other._starttime))
      return false;
    if (this._duration == null) {
      if (other._duration != null)
        return false;
    } else if (!this._duration.equals(other._duration))
      return false;
    if (this.__route == null) {
      if (other.__route != null)
        return false;
    } else if (!this.__route.equals(other.__route))
      return false;
    return true;
  }
  
  @Override
  @Pure
  public String toString() {
    String result = new ToStringHelper().toString(this);
    return result;
  }
  
  @Pure
  public Long getId() {
    return this._id;
  }
  
  @Pure
  public String getType() {
    return this._type;
  }
  
  @Pure
  public String getLocation() {
    return this._location;
  }
  
  @Pure
  public double getDistance() {
    return this._distance;
  }
  
  @Pure
  public DateTime getStarttime() {
    return this._starttime;
  }
  
  @Pure
  public Duration getDuration() {
    return this._duration;
  }
  
  @Pure
  public List<Location> getRoute() {
    return this.__route;
  }
  
  @Pure
  public List<Location> get_route() {
    return this.__route;
  }
}
