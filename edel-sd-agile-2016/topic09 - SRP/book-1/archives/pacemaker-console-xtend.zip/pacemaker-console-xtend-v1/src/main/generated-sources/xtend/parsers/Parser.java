package parsers;

import java.util.Collection;
import models.Activity;
import models.User;

@SuppressWarnings("all")
public class Parser {
  public String renderUser(final User user) {
    return user.toString();
  }
  
  public String renderUsers(final Collection<User> users) {
    return users.toString();
  }
  
  public String renderActivities(final Collection<Activity> activities) {
    return activities.toString();
  }
}
