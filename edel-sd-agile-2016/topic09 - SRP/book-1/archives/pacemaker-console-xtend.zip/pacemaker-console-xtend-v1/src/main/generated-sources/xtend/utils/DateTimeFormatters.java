package utils;

import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.PeriodFormatter;
import org.joda.time.format.PeriodFormatterBuilder;

@SuppressWarnings("all")
public class DateTimeFormatters {
  private final static PeriodFormatter periodFormatter = new PeriodFormatterBuilder().printZeroAlways().appendHours().appendSeparator(":").appendMinutes().appendSeparator(":").appendSeconds().toFormatter();
  
  private final static DateTimeFormatter dateFormatter = DateTimeFormat.forPattern("dd:MM:yyyy HH:mm:ss");
  
  public static DateTime parseDateTime(final String dateTime) {
    DateTime _parseDateTime = DateTimeFormatters.dateFormatter.parseDateTime(dateTime);
    return new DateTime(_parseDateTime);
  }
  
  public static String parseDateTime(final DateTime dateTime) {
    return DateTimeFormatters.dateFormatter.print(dateTime);
  }
  
  public static Duration parseDuration(final String duration) {
    Period _parsePeriod = DateTimeFormatters.periodFormatter.parsePeriod(duration);
    return _parsePeriod.toStandardDuration();
  }
  
  public static String parseDuration(final Duration duration) {
    Period _period = duration.toPeriod();
    return DateTimeFormatters.periodFormatter.print(_period);
  }
}
