package controllers;

import controllers.PacemakerAPI;
import java.io.File;
import java.util.Collection;
import java.util.Map;
import java.util.function.Consumer;
import models.Activity;
import models.Fixtures;
import models.Location;
import models.User;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import utils.DateTimeFormatters;
import utils.JSONSerializer;
import utils.Serializer;
import utils.XMLSerializer;

@SuppressWarnings("all")
public class PersistenceTest {
  private PacemakerAPI pacemaker;
  
  private Serializer xmlSerializer;
  
  private Serializer jsonSerializer;
  
  private final String datastoreFile = "testdatastore";
  
  public void deleteFile(final String fileName) {
    final File datastore = new File(fileName);
    boolean _exists = datastore.exists();
    if (_exists) {
      datastore.delete();
    }
  }
  
  public void populate() {
    final Consumer<User> _function = new Consumer<User>() {
      public void accept(final User it) {
        String _firstname = it.getFirstname();
        String _lastname = it.getLastname();
        String _email = it.getEmail();
        String _password = it.getPassword();
        PersistenceTest.this.pacemaker.createUser(_firstname, _lastname, _email, _password);
      }
    };
    Fixtures.users.forEach(_function);
    final User marge = this.pacemaker.getUser("marge@simpson.com");
    final Consumer<Activity> _function_1 = new Consumer<Activity>() {
      public void accept(final Activity it) {
        Long _id = marge.getId();
        String _type = it.getType();
        String _location = it.getLocation();
        double _distance = it.getDistance();
        DateTime _starttime = it.getStarttime();
        String _parseDateTime = DateTimeFormatters.parseDateTime(_starttime);
        Duration _duration = it.getDuration();
        String _parseDuration = DateTimeFormatters.parseDuration(_duration);
        PersistenceTest.this.pacemaker.createActivity(_id, _type, _location, _distance, _parseDateTime, _parseDuration);
      }
    };
    Fixtures.margesActivities.forEach(_function_1);
    final Consumer<Location> _function_2 = new Consumer<Location>() {
      public void accept(final Location it) {
        Map<Long, Activity> _activities = marge.getActivities();
        Collection<Activity> _values = _activities.values();
        Activity _get = ((Activity[])Conversions.unwrapArray(_values, Activity.class))[0];
        Long _id = _get.getId();
        float _latitude = it.getLatitude();
        float _longitude = it.getLongitude();
        PersistenceTest.this.pacemaker.addLocation(_id, _latitude, _longitude);
      }
    };
    Fixtures.locations.forEach(_function_2);
    final User lisa = this.pacemaker.getUser("lisa@simpson.com");
    final Consumer<Activity> _function_3 = new Consumer<Activity>() {
      public void accept(final Activity it) {
        Long _id = lisa.getId();
        String _type = it.getType();
        String _location = it.getLocation();
        double _distance = it.getDistance();
        DateTime _starttime = it.getStarttime();
        String _parseDateTime = DateTimeFormatters.parseDateTime(_starttime);
        Duration _duration = it.getDuration();
        String _parseDuration = DateTimeFormatters.parseDuration(_duration);
        PersistenceTest.this.pacemaker.createActivity(_id, _type, _location, _distance, _parseDateTime, _parseDuration);
      }
    };
    Fixtures.lisasActivities.forEach(_function_3);
  }
  
  @Before
  public void setup() {
    this.deleteFile(this.datastoreFile);
    XMLSerializer _xMLSerializer = new XMLSerializer(this.datastoreFile);
    this.xmlSerializer = _xMLSerializer;
    JSONSerializer _jSONSerializer = new JSONSerializer(this.datastoreFile);
    this.jsonSerializer = _jSONSerializer;
    PacemakerAPI _pacemakerAPI = new PacemakerAPI();
    this.pacemaker = _pacemakerAPI;
    this.populate();
  }
  
  @After
  public void tearDown() {
    this.pacemaker = null;
    this.xmlSerializer = null;
    this.jsonSerializer = null;
  }
  
  @Test
  public void testXMLSerializer() {
    try {
      this.pacemaker.setSerializer(this.xmlSerializer);
      this.pacemaker.store();
      final PacemakerAPI pacemaker2 = new PacemakerAPI();
      pacemaker2.setSerializer(this.xmlSerializer);
      pacemaker2.load();
      Collection<User> _users = this.pacemaker.getUsers();
      final Consumer<User> _function = new Consumer<User>() {
        public void accept(final User it) {
          Collection<User> _users = pacemaker2.getUsers();
          boolean _contains = _users.contains(it);
          Assert.assertTrue(_contains);
        }
      };
      _users.forEach(_function);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void testJSONSerializer() {
    try {
      this.pacemaker.setSerializer(this.jsonSerializer);
      this.pacemaker.store();
      final PacemakerAPI pacemaker2 = new PacemakerAPI();
      pacemaker2.setSerializer(this.jsonSerializer);
      pacemaker2.load();
      Collection<User> _users = this.pacemaker.getUsers();
      final Consumer<User> _function = new Consumer<User>() {
        public void accept(final User it) {
          Collection<User> _users = pacemaker2.getUsers();
          boolean _contains = _users.contains(it);
          Assert.assertTrue(_contains);
        }
      };
      _users.forEach(_function);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
