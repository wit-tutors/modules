package models;

import java.util.ArrayList;
import models.Activity;
import models.Location;
import models.User;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.joda.time.DateTime;
import org.joda.time.Duration;

@SuppressWarnings("all")
public class Fixtures {
  public static ArrayList<User> users = CollectionLiterals.<User>newArrayList(
    new User(Long.valueOf(1l), "marge", "simpson", "marge@simpson.com", "secret"), 
    new User(Long.valueOf(2l), "lisa", "simpson", "lisa@simpson.com", "secret"), 
    new User(Long.valueOf(3l), "bart", "simpson", "bart@simpson.com", "secret"), 
    new User(Long.valueOf(4l), "maggie", "simpson", "maggie@simpson.com", "secret"));
  
  public static ArrayList<Activity> activities = CollectionLiterals.<Activity>newArrayList(
    new Activity(Long.valueOf(1l), "walk", "fridge", 0.001, new DateTime(2013, 5, 12, 9, 30), new Duration(10000)), 
    new Activity(Long.valueOf(2l), "walk", "bar", 1.0, new DateTime(2013, 5, 17, 10, 30), new Duration(30000)), 
    new Activity(Long.valueOf(3l), "run", "work", 2.2, new DateTime(2013, 6, 10, 11, 00), new Duration(50000)), 
    new Activity(Long.valueOf(4l), "walk", "shop", 2.5, new DateTime(2013, 7, 22, 9, 00), new Duration(60000)), 
    new Activity(Long.valueOf(5l), "cycle", "school", 4.5, new DateTime(2013, 8, 30, 9, 30), new Duration(70000)));
  
  public static ArrayList<Location> locations = CollectionLiterals.<Location>newArrayList(
    new Location(23.3f, 33.3f), 
    new Location(34.4f, 45.2f), 
    new Location(25.3f, 34.3f), 
    new Location(44.4f, 23.3f));
  
  public final static ArrayList<Activity> margesActivities = CollectionLiterals.<Activity>newArrayList(
    Fixtures.activities.get(0), Fixtures.activities.get(1), Fixtures.activities.get(2));
  
  public final static ArrayList<Activity> lisasActivities = CollectionLiterals.<Activity>newArrayList(
    Fixtures.activities.get(3), Fixtures.activities.get(4));
  
  public final static ArrayList<Location> route1 = CollectionLiterals.<Location>newArrayList(
    Fixtures.locations.get(0), Fixtures.locations.get(1));
  
  public final static ArrayList<Location> route2 = CollectionLiterals.<Location>newArrayList(
    Fixtures.locations.get(2), Fixtures.locations.get(3));
}
