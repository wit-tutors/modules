package models;

import java.util.HashMap;
import models.User;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class FixturesComposite {
  public final static HashMap<Long, User> userMap = CollectionLiterals.<Long, User>newHashMap(
    Pair.<Long, User>of(Long.valueOf(01l), new User(Long.valueOf(1l), "marge", "simpson", "marge@simpson.com", "secret")));
}
