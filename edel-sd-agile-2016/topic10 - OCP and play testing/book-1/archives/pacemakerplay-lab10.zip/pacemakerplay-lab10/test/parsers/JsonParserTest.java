package parsers;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.containsString;
import org.junit.Test;
import models.User;
import play.test.WithApplication;

public class JsonParserTest extends WithApplication{

	@Test
	public void userConvertsToJsonStringAndBackAgain() {		
  	    // Create a new user and save it in the database
	    new User("Jim", "Simpson", "jim@simpson.com", "secret").save();
	    
	    // Retrieve the user we just added by their email address
	    User joesoap = User.findByEmail("jim@simpson.com");
	    
	    //Test the parsing of the User into a String
	    String jsonReturned = JsonParser.renderUser(joesoap);
	    
	    // Test the String returned from the parse contains the user data
	    assertNotNull(jsonReturned);
	    assertThat(jsonReturned, containsString("jim@simpson.com"));
	    assertThat(jsonReturned, containsString("Jim"));
	    assertThat(jsonReturned, containsString("Simpson"));
	    assertThat(jsonReturned, containsString("secret"));
	 
	    // Test the String returned from the parse re-renders into user object format
	    assertThat(joesoap, equalTo(JsonParser.renderUser(jsonReturned)));    
	}
}	



