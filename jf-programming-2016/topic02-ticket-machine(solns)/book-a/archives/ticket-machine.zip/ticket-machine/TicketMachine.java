class TicketMachine
{
    private int price;
    private int balance;
    private int total;

    public TicketMachine(int ticketCost)
    {
        if(ticketCost > 0) 
        {
            price = ticketCost;
            balance = 0;
            total = 0;      
        }
        else
        {
            System.out.println("Invalid ticketCost");
            System.out.println("Please insert a valid ticket cost");
        }
    }

    public int getPrice()
    {
        return price;
    }

    public int getBalance()
    {
        return balance;
    }

    public void insertMoney(int amount)
    {
        if(amount > 0) 
        {
            balance = balance + amount;
        }
        else
        {
            System.out.println("Invalid operation");
            System.out.println("Please insert a positive amount of money");
        }
    }

    public void printTicket()
    {
        if(balance >= price)
        {
            System.out.println("##################");
            System.out.println("# The BlueJ Line");
            System.out.println("# Ticket");
            System.out.println("# " + price + " cents.");
            System.out.println("##################");
            System.out.println();

            total = total + price;
            balance = balance - price;
        }
        else
        {
           int deficit = price - balance;
           System.out.println("You must insert at least: " +
                               deficit + " more cents."); 
        }
    }

    public int refundBalance()
    {
        int amountToRefund = balance;
        balance = 0;
        return amountToRefund;
    }
}