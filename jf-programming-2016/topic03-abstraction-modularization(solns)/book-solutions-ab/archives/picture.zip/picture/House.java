public class House
{
    private Triangle roof;
    private Rectangle wall;
    private Rectangle window; 
  
    public House()
    {
        createWall("red");
        createWindow();
        createRoof();
    }
    
    public House(String color)
    {
        createWall(color);
        createWindow();
        createRoof();
    }
    
        private void createWall(String color) 
    {
        int xSideLength = 125;
        int ySideLength = 100;
        int xPosition = 25;
        int yPosition = 125;
  
        wall = new Rectangle(xSideLength, ySideLength, xPosition, yPosition, color);
        
    }    
    
    private void createWindow() 
    {
        int xSideLength = 25;
        int ySideLength = 50;
        int xPosition = 45;
        int yPosition = 150;
        String color = "black";
        
        window = new Rectangle(xSideLength, ySideLength, xPosition, yPosition, color);
    }
    
    private void createRoof() 
    {
        int height = 60;
        int width = 150;
        int xPosition = 87;
        int yPosition = 75;
        String color = "green";
        
        roof = new Triangle(height, width, xPosition, yPosition, color);
    }
    
    public void display(boolean show)
    {
        if(show)
        {
            roof.makeVisible();
            wall.makeVisible();
            window.makeVisible();
        }
        else
        {
            roof.makeInvisible();
            wall.makeInvisible();
            window.makeInvisible();
        }
    }
    
    public void moveTo(int x, int y)
    {
        int xWall = x - wall.getWidth()/2;
        int yWall = y + roof.getHeight();
        int xWindow = xWall + wall.getWidth()/5;
        int yWindow = yWall + wall.getHeight()/4; 
        roof.moveTo(x,y);
        wall.moveTo(xWall, yWall);
        window.moveTo(xWindow, yWindow);
    }
}
