

public class Picture
{
    private House   house;
    private Tree    tree;
    private Sun  sun;
    public Picture()
    {
        house   = new House();
        tree    = new Tree();
        sun     = new Sun();
        position();
    }

    public void display(boolean show)
    {
        if(show)
        {
            house.display(true);
            tree.display(true);
            sun.display(true);
        }
        else
        {
            house.display(false);
            tree.display(false);
            sun.display(false);
        }
    }
    
    private void position()
    {
        int xRoof = 100;
        int yRoof = 100;
        house.moveTo(xRoof, yRoof);
        tree.moveTo(xRoof + 100, yRoof + 100);
        sun.moveTo(xRoof + 150, yRoof - 50);
    }
}
