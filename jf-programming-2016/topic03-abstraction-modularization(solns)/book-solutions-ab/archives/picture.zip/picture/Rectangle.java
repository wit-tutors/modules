

/**
 * @file    Rectangle.java
 * @brief   This class describes a rectangle and includes 
 *                  methods to change rectangle objects' size and appearance.
 * @version 1.0 April 1, 2014
 * @author   Michael Kolling and David J. Barnes
 * @author  <your name here>
 */

public class Rectangle
{
    private int xSideLength;
    private int ySideLength;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * Constructs a new RectangleBJ defined by default data
     */
    public Rectangle()
    {
        xSideLength = 60;
        ySideLength = 30;
        xPosition = 60;
        yPosition = 50;
        color = "red";
        isVisible = false;
        setState(60, 30, 60, 50, "red"); 
    }

    /**
     * Constructs a new RectangleBJ defined by user-supplied parameters
     * @param xSideLength the length of the rectangle
     * @param ySideLength the width or height of the rectangle
     * @param xPosition the x-coordinate of the top left corner of the rectangle
     * @param yPosition the y-coordinate of the top left corner of the rectanglep
     * @param color the colour of the rectangle including perimeter and body
     */
    public Rectangle(int xSideLength, int ySideLength, int xPosition, int yPosition, String color)
    {
        setState(xSideLength, ySideLength, xPosition, yPosition, color);
    }
    
    /**
     * Public method to facilitate initialization or re-initialization of the rectangle
     * @param xSideLength the length of the rectangle
     * @param ySideLength the width or height of the rectangle
     * @param xPosition the x-coordinate of the top left corner of the rectangle
     * @param yPosition the y-coordinate of the top left corner of the rectanglep
     * @param color the colour of the rectangle including perimeter and body
     */
    public void setState(int xSideLength, int ySideLength, int xPosition, int yPosition, String color)
    {
        this.xSideLength = xSideLength;
        this.ySideLength = ySideLength;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.color = color;
        isVisible = true;
    }

    public int getWidth()
    {
        return xSideLength;
    }
    
    public int getHeight()
    {
        return ySideLength;
    }
    
    
    public void makeVisible()
    {
        isVisible = true;
        draw();
    }

    public void makeInvisible()
    {
        erase();
        isVisible = false;
    }

    public void moveTo(int x, int y)
    {
        xPosition = x;
        yPosition = y;
        makeVisible();
    }

    public void moveRight()
    {
        moveHorizontal(20);
    }

    public void moveLeft()
    {
        moveHorizontal(-20);
    }

    public void moveUp()
    {
        moveVertical(-20);
    }

    public void moveDown()
    {
        moveVertical(20);
    }

    public void moveHorizontal(int distance)
    {
        erase();
        xPosition += distance;
        draw();
    }

    public void moveVertical(int distance)
    {
        erase();
        yPosition += distance;
        draw();
    }

    public void slowMoveHorizontal(int distance)
    {
        int delta;

        if(distance < 0) 
        {
            delta = -1;
            distance = -distance;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distance; i++)
        {
            xPosition += delta;
            draw();
        }
    }

    public void slowMoveVertical(int distance)
    {
        int delta;

        if(distance < 0) 
        {
            delta = -1;
            distance = -distance;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distance; i++)
        {
            yPosition += delta;
            draw();
        }
    }
    
    
    public void changeSize(int xSideLength, int ySideLength)
    {
        if(xSideLength > 0 && ySideLength > 0) 
        {
            erase();
            this.xSideLength = xSideLength;
            this.ySideLength = ySideLength;
            draw();
        }
        else
        {
            System.out.println("Enter positive dimensions");
        }

    }

    public void changeColor(String color)
    {
        this.color = color;
        draw();
    }

    private void draw()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                    new java.awt.Rectangle(xPosition, yPosition, xSideLength, ySideLength));
            canvas.wait(10);
        }
    }

    private void erase()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}