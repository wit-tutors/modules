public class Sun
{
    Circle sun;
    
    public Sun()
    {
        sun = new Circle();
        changeColor("yellow");
    }
    
    public void changeColor(String color)
    {
        sun.changeColor(color);
    }
    
    public void moveTo(int x, int y)
    {
        sun.moveTo(x, y);
    }
    
    public void display(boolean show)
    {
        if(show)
        {
            sun.makeVisible();
        }
        else
        {
            sun.makeInvisible();
        }
    }
}
