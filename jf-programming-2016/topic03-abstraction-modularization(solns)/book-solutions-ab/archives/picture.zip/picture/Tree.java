 

public class Tree
{
    private Triangle treeBase;
    private Triangle treeMiddle;
    private Triangle treeTop;
    private Rectangle treeTrunk;

    public Tree()
    {
       createTreeBase();
       createTreeMiddle();
       createTreeTop();
       createTreeTrunk();
    }

  
    private void createTreeBase()
    {
        // Triangle (height, width, xPosition, yPosition, color)
        treeBase = new Triangle(30, 50, 100, 70, "green");
    }
    
   private void createTreeMiddle()
    {
        // Triangle (height, width, xPosition, yPosition, color)
        treeMiddle = new Triangle(30, 45, 100, 55, "green");
    }
    
   private void createTreeTop()
    {
        // Triangle (height, width, xPosition, yPosition, color)
        treeTop = new Triangle(30,40, 100, 40, "green");
    }
     
    private void createTreeTrunk()
    {
        // Rectangle(xSideLen, ySideLen, xPosition, yPosition, color)
        treeTrunk = new Rectangle(3, 30, 100, 100, "black");
    }
    
    public void display(boolean show)
        {
            if(show)
            {
                treeBase.makeVisible();
                treeMiddle.makeVisible();
                treeTop.makeVisible();
                treeTrunk.makeVisible();
            }
            else
            {
                treeBase.makeInvisible();
                treeMiddle.makeInvisible();
                treeTop.makeInvisible();
                treeTrunk.makeInvisible();
            }
        }    

    /**
     * Moves tree as a unit
     * @param x The destination x coordinate
     * @param y The destination y coordinate
     */
    public void moveTo(int x, int y)
    {
     //we require the heights of each triangle to calculate 
     //the coordinate of each apex following move
     int heightBase = treeBase.getHeight();
     int heightMiddle = treeMiddle.getHeight();
     int heightTop = treeTop.getHeight();
     //these are the y coordinates of each tree segment relative to 
     //the coordinates of the tree trunk
     //note the coordinates of the tree trunk refer to the top of the trunk
     int yBase = y - heightBase;
     int yMiddle = yBase - heightBase/2;
     int yTop = yMiddle - heightMiddle/2;
    
     treeTrunk.moveTo(x, y);
     treeBase.moveTo(x, yBase);
     treeMiddle.moveTo(x, yMiddle);
     treeTop.moveTo(x, yTop);
       

    }
}