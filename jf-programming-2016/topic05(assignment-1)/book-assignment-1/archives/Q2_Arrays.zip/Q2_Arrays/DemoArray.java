import java.util.ArrayList;
import java.util.Iterator;

public class DemoArray {
    private int[] intArray;
    private int size = 10;
    
    
    public DemoArray() {
        
    }

    /*
     * Use a for loop to initialize each element in the array with 100 + i.
     * Use a similar loop to output the array.
     */
    public void demoArray() {
        
    }

    /*
     * Use a while loop to initialize each element in the array with 200 + 2*i.
     * Use a similar loop to output the array.
     */
    public void demoArray2() {

        
    }

    /*
     * Use a do-while loop to initialize each element in the array with 300 + 3*i.
     * Use a similar loop to output the array.
     */
    public void demoArray3() {

        
    }

    /*
     * Use an iterator to initialize each element in the array with 400 + 4*i.
     * Use a similar loop to output the array.
     */
    public void demoArray4() {
        

    }

	/**
	 * Create an array of even numbers in range [low, hi]
	 * Precondition: low and hi must be even. 
	 * Enforce precondition: print message if not met and return immediately.
	 * Calculate and print the sum of these numbers.
	 * 
	 * @param low The minimum range value inclusive
	 * @param hi The maximum range value inclusive
	 */
	public void sumEven(int low, int hi)
	{
	    // Check preconditions. If not complied with print message and return.
	    // Message: Please enter even arguments
	     
	    // Declare and allocate memory to array of int type
	    
	    // In a loop, initialize the array with even numbers in range [lo, hi]
	    
	    // In a second loop. accessing the above array, calculate the cumulative sum of the even numbers.
		// Print the sum as part of a message structured as follows, for example, where
		// range is [0, 10] and consequently sum is 30
		// Sum even numbers from 0 to 10 is 30
	}

}
