/**
 * @file    Book.java
 * @brief   This class defines the basic description of a book and provides some characteristic methods.
 * @version  
 * @author   
 */
public class Book
{


}
