
/**
 * @file    Sphere.java
 * @brief   This class describes a sphere and includes 
 *                  methods to calculate properties such as surface area and volume.
 * @author john fitzgerald
 * @version 26-2-2016
 */
public class Sphere
{
  /**
   * The radius of the sphere
   */
  double radius;
  /**
   * Maintains a count of the number of spheres instantiated during current session.
   */
  static int numberSpheres = 0;

  /**
   * Initializes a default Sphere object.
   * Chooses an arbitrary radius equal to 10 units.
   */
  public Sphere()
  {
    setState(10);
    numberSpheres += 1;
  }

  /**
   * Initializes a sphere with defined radius.
   * 
   * @param radius The radius of the sphere
   */
  public Sphere(double radius)
  {
    setState(radius);
    numberSpheres += 1;
  }

  /**
   * Evaluates and returns the surface area of this sphere.
   * 
   * @return The surface area of the sphere
   */
  public double surfaceArea()
  {
    return Math.PI * Math.pow(radius, 2) * 4;
  }

  /**
   * Evaluates and returns the volume of this sphere.
   * 
   * @return The volume of the sphere
   */ 
  public double volume()
  {
    return 4 * Math.PI * Math.pow(radius, 3) / 3;
  }

  /**
   * Faclitates changing the size of the sphere.
   * 
   * @param radius The radius of the modified sphere
   */
  public void changeSize(double radius)
  {
    setState(radius);
  }

  /**
   * Returns the number of spheres instantiated during current session.
   * 
   * @return The number of spheres instantiated during current session.
   */
  public int getNumberSpheres()
  {
    return numberSpheres;
  }

  /**
   * A private helper method to set the value of the radius.
   * 
   * @param radius The radius with which this sphere to be initialized.
   */
  private void setState(double radius)
  {
    if (isValid(radius))
    {
      this.radius = radius;
    }
    else
    {
      String s1 = "You have attempted to create a sphere with a negative radius";
      String s2 = "Only positive radii permitted";
      System.out.println(s1 + "\n" + s2);
    }
  }

  /**
   * A private helper method to validate a value.
   * A valid number is one greater than zero.
   * 
   * @param val The number to be validated.
   * @return true if the number is valid.
   */
  private boolean isValid(double val)
  {
    if (val < 0)
    {
      return false;
    }
    return true;
  }

}
