import java.util.ArrayList;
import java.util.Iterator;

/**
 * @file DemoArray.java
 * @brief A class containing methods to obtain experience in the use of
 *        traversal techniques using for, while, do-while and iteration
 *        techniques.
 * @author j fitzgerald
 * @version 26.2.2016
 *
 */
public class DemoArray
{
    /**
     * An array of primitive integers used in the various methods below.
     */
    private int[] intArray;
    /**
     * The size of the intArray.
     */
    private int size = 10;

    /**
     * Initializes a newly created DemoArray object. The instance variable
     * intArray is initialized.
     */
    public DemoArray()
    {
        intArray = new int[size];
    }

    /**
     * Use a for loop to initialize each element in the array with 100 + i. Use a
     * similar loop to output the array.
     */
    public void demoArray()
    {
        for (int i = 0; i < size; i += 1)
        {
            intArray[i] = 100 + i;
        }

        for (int i = 0; i < size; i += 1)
        {
            System.out.println("Element at index " + i + " is " + intArray[i]);
        }
    }

    /**
     * Use a while loop to initialize each element in the array with 200 + 2*i.
     * Use a similar loop to output the array.
     */
    public void demoArray2()
    {

        int i = 0;
        while (i < size)
        {
            intArray[i] = 200 + 2 * i;
            i += 1;
        }

        i = 0;
        while (i < size)
        {
            System.out.println("Element at index " + i + " is " + intArray[i]);
            i += 1;
        }
    }

    /**
     * Use a do-while loop to initialize each element in the array with 300 + 3*i.
     * Use a similar loop to output the array.
     */
    public void demoArray3()
    {

        int i = 0;
        do
        {
            intArray[i] = 300 + 3 * i;
            i += 1;
        } while (i < size);

        i = 0;
        do
        {
            System.out.println("Element at index " + i + " is " + intArray[i]);
            i += 1;
        } while (i < size);
    }

    /**
     * Use an iterator to initialize each element in the array with 400 + 4*i. Use
     * a similar loop to output the array.
     */
    public void demoArray4()
    {
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < size; i += 1)
        {
            list.add(400 + 4 * i);
        }

        Iterator<Integer> it = list.iterator();
        while (it.hasNext())
        {
            Integer integer = it.next();
            int index = list.lastIndexOf(integer);
            System.out.println("Element at index " + index + " is " + integer);
        }

    }

    /**
     * Create an array of even numbers in range [low, hi]. 
     * Precondition: low and hi must be even. 
     * Enforce precondition: print message if not met and return immediately. 
     * Calculate and print the sum of these numbers.
     * 
     * @param low The minimum range value inclusive
     * @param hi The maximum range value inclusive
     */
    public void sumEven(int low, int hi)
    {
        if ((low % 2 != 0) || (hi % 2 != 0))
        {
            System.out.println("\nPlease enter even arguments");
            return;
        }

        int[] ar = new int[(hi - low) / 2 + 1];

        int index = 0;
        for (int i = low; i <= hi; i += 2)
        {
            ar[index++] = i;
        }

        int sum = 0;
        for (int i = 0; i < ar.length; i += 1)
        {
            sum += ar[i];
        }
        System.out.println("\nSum even numbers from " + low + " to " + hi + " inclusive is " + sum);
    }

}
