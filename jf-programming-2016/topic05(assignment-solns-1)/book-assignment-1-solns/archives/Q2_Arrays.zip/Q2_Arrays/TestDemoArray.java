
/**
 * This class contains a method to test the methods in the DemoArray class.
 * 
 * @author jfitzgerald
 * @version 29.1.2016
 */
public class TestDemoArray
{
    /**
     * Instantiates a local DemoArray object.
     * Invokes the DemoArray methods on this object.
     */
    public static void testDemoArray()
    {
        DemoArray obj = new DemoArray();
		System.out.print("DemoArray\n");
		obj.demoArray();
		System.out.print("\nDemoArray2\n");
		obj.demoArray2();
		System.out.print("\nDemoArray3\n");
		obj.demoArray3();
		System.out.print("\nDemoArray4\n");
		obj.demoArray4();
        obj.sumEven(0, 10);
    }
}
