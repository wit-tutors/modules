/**
 * @file Book.java
 * @brief This class provides a basic description of a book and provides some
 *        characteristic methods.
 * @version 5.2.2016
 * @author j fitzgerald
 */
public class Book
{

    String title;
    String author;
    String isbn;
    int numberPages;
    boolean borrowed;
    int numberBorrowings;

    /**
     * Sole constructor
     * 
     * @param title
     *          the complete book title
     * @param author
     *          the author or authors
     * @param isbn
     *          the International Standard Book Number 2005 edition (ISBN-13)
     */
    public Book(String title, String author, int numberPages, String isbn)
    {
        this.title = title;
        this.author = author;
        this.numberPages = numberPages;
        this.isbn = isbn;
        borrowed = false;
        numberBorrowings = 0;
    }

    /**
     * Simulates borrowing of book Checks if book already borrowed (on loan). If
     * not already on loan, increments the number of borrowings and changes state
     * to reflect book now being borrowed.
     */
    public void borrow()
    {
        if (!borrowed)
        {
            numberBorrowings += 1;
            borrowed = true;
        }
        else
        {
            System.out.println("Book on loan");
        }
    }

    /**
     * Informs whether or not book is borrowed, that is, presently out on loan
     * 
     * @return true if the book is presently borrowed else returns false
     */
    public boolean isBorrowed()
    {
        return borrowed;
    }

    /**
     * Return the title of book
     * 
     * @return title The title of the book
     */
    public String bookTitle()
    {
        return title;
    }

    public String loanStatus()
    {
        if (borrowed)
            return title + " not available: presently on loan";
        else
            return title + " is available";
    }

    /**
     * Method that simulates returning of borrowed book to the library. Alters the
     * book object state to reflect the changed status.
     */
    public void returns()
    {
        borrowed = false;
    }

    /**
     * Prints summary data relating to book. 
     * This includes the title, author, ISBN, how many times the book has been borrowed and its present loan status.
     */
    public void printDetails()
    {
        System.out.println("Title       :  " + title);
        System.out.println("Author      :  " + author);
        System.out.println("Pages       :  " + numberPages);
        System.out.println("ISBN        :  " + isbn);
        System.out.println("Borrowed    :  " + numberBorrowings + " times");
        System.out.println("Availability:  " + loanStatus());
        System.out.println();
    }

}
