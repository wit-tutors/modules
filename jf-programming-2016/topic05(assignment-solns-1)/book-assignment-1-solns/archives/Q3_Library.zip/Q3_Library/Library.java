import java.util.ArrayList;

/**
 * @file Library.java
 * @brief This class represents a library. It contains a list of books and a
 *        series of methods to perform related actions. on a simple library and
 *        its books.
 * @version 26.2.2016
 * @author j fitzgerald
 */
public class Library
{
    /**
     * The list of books in the library.
     */
    ArrayList<Book> books = new ArrayList<Book>();

    /**
     * Adds a book to the library
     * 
     * @param book
     *          The book to be added to the library.
     */
    public void add(Book book)
    {
        books.add(book);
    }

    /**
     * Obtains the number of books in the library.
     * 
     * @return Returns the number of books in the library.
     */
    public int numberBooks()
    {
        return books.size();
    }

    /**
     * Determines the loan status of a specific book. That is, is it available or
     * presently out on loan?
     * 
     * @param book
     *          The book whose status if being queried.
     * @return The status of the book.
     */
    public String loanStatus(Book book)
    {
        return book.loanStatus();
    }

    /**
     * Determines if the library has a specific book. That is, does the library
     * stock this book and if so is it available or on loan?
     * 
     * @param book
     *          The book being queried.
     * @return Information relating to the book: does the library stock this book
     *         and if so is it available or on loan?
     */
    public String hasBook(Book book)
    {
        if (books.contains(book) == true && book.isBorrowed() == false)
        {
            return "Book title " + book.title + " in stock and available to borrow";
        }
        else
        if (books.contains(book) == true && book.isBorrowed() == true)
        {
            return "Book in stock and presently out on loan";
        }
        return "We do not stock book title " + book.title;
    }

    /**
     * Remove a book from the library.
     * 
     * @param book
     *          The book to be removed from the library.
     * @return Returns true if the book successfully removed from the library.
     */
    public boolean removeBook(Book book)
    {
        return books.remove(book);
    }

    /**
     * Remove all books from the library.
     */
    public void removeAllBooks()
    {
        books.clear();
    }

    /**
     * Print details of all books in the library by querying all books and
     * printing their individual details.
     */
    public void printDetailsAll()
    {
        for (Book book : books)
        {
            book.printDetails();
        }
    }
}
