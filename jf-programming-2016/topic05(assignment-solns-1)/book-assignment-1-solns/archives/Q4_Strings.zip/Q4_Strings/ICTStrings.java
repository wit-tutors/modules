/**
 * @file ICTStrings.java
 * @brief This class exercises a subset of the String class functionality.
 * @version 5.2.2016
 * @author j fitzgerald
 */
public class ICTStrings
{
    /**
     * Check is s1 is equal to s2
     * @param s1 a string
     * @param s2 another string
     * @return true if strings equal else false
     */
    public static boolean isEqual(String s1, String s2)
    {
        return s1.equals(s2);
    }

    /**
     * Check is s1 is equal to s2 ignoring case
     * @param s1 a string
     * @param s2 another string
     * @return true if strings equal, ignoring case, else false
     */
    public static boolean isEqualIgnoreCase(String s1, String s2)
    {
        return s1.equalsIgnoreCase(s2);
    }

    /**
     * Check if s1 has prefix
     * @param a string
     * @param another string
     * @return true
     */
    public static boolean hasPrefix(String s1, String prefix)
    {
        return s1.startsWith(prefix);
    }

    /**
     * Length string comprising concatenated strings s1 and s2
     * @param s1 a string
     * @param s2 another string
     * @return length of s1 concatenated with s2
     */
    public static int length(String s1, String s2)
    {
        return (s1 + s2).length();
    }

    /**
     * Create string the uppercase version of s1
     * @param s1 a string
     * @return copy of s1 all in upper case
     */
    public static String toUpper(String s1)
    {
        return s1.toUpperCase();
    }

    /**
     * Returns true if string ends with suffix.
     * Example if s1 is "this is a string" and suffix is "ring" the return value will be true.
     * @param s1 a string
     * @param suffix a string
     * @return true if s1 ends in suffix
     */
    public static boolean endsWith(String s1, String suffix)
    {
        return s1.endsWith(suffix);
    }

    /**
     * Create substring of s1 from indexStart to indexEnd excluding indexEnd
     * That is: range is [indexStart, indexEnd)
     * Example String "Hello ICTSkills"
     * indexStart = 2;
     * indexEnd = 8;
     * substring is "llo IC"
     * @param s1 a string
     * @param indexStart of s1 becomes zeroth index of substring
     * @param indexEnd of s1 determines end of substring
     * @return the substring
     */
    public static String subString(String s1, int indexStart, int indexEnd)
    {
        return s1.substring(indexStart, indexEnd);
    }

    /**
     * Create a string, the reverse of string using StringBuilder
     * @param string the string to be reversed
     * @return a copy of string reversed
     */
    public static String reverse_1(String string)
    {
        return new StringBuilder(string).reverse().toString();
    }

    /**
     * Create a string, the reverse of string
     * An array of char type of same size of string is instantiated.
     * In a for loop the string characters are assigned to the array in reverse order.
     * The array is used to create a string which is then returned.
     * This string will be the reverse of the actual parameter string.
     * 
     * @param string The string to be reversed
     * @return  A reversed copy of parameter string
     */
    public static String reverse_2(String string)
    {
        //decompose string into array of individual characters
        //array order the reverse of chars in argument string
        int length = string.length();
        char[] characters = new char[length];
        for(int i = 0; i < length; i += 1)
        {
            characters[i] = string.charAt(length - 1 - i);
        }
        return new String(characters);
    }

    /**
     * Alternative solution.
     * Create a string, the reverse of string
     * 
     * @param string The string to be reversed
     * @return  A reversed copy of parameter string
     */
    public static String reverse_2_1(String string)
    {
        String reverseString = "";        
        for(int i = string.length() - 1; i >= 0; i -= 1)
        {
            reverseString += string.charAt(i);
        }
        
        return reverseString;
    }

    /**
     * Create a string, the reverse of string
     * Use a StringBuffer class.
     * @param string the string to be reversed
     * @return a copy of string reversed
     */
    public static String reverse_3(String string)
    {       
        return new StringBuffer(string).reverse().toString();
    }
    
    /** 
     * Check if string is a palindrome. 
     * Enforce condition that string to be checked
     * comprises only upper and lower case letters. 
     * Uses ICTStrings.reverse_3.
     * 
     * @param string Is s a palindrome?
     * @return Returns true if argument is a palindrome.
     */
    public static boolean isPalindrome(String string)
    {
        // Create a copy of the parameter in which only upper and lower case letters included.
        String smod = string.replaceAll("[^a-zA-Z]", "");
        // Check if this copy is a palindrome
        return reverse_3(smod).equalsIgnoreCase(smod);
    }

    /** 
     * Check if string is a palindrome. 
     * Enforce condition that string to be checked
     * comprises only upper and lower case letters.
     * 
     * @param string Is s a palindrome?
     * @return Returns true if argument is a palindrome.
     */
    public static boolean isPalindrome2(String string)
    {
      // Creates a trimmed lower-case copy of parameter in which only upper and lower case letters included.
      String smod = string.replaceAll("[^a-zA-Z]", "").toLowerCase();
      // Traverses first half of modified string, comparing each successive character with its corresponding
      // character in the second half of the string. If any pair of characters are found to be not equal then the
      // string is not a palindrome
      int length = smod.length();
      for (int i = 0; i < length/2; i += 1) 
      {
        if (smod.charAt(i) != smod.charAt(length - 1 - i) )
        {
          return false;
        }
      }
      return true;
    }
}
