/**
 * @file TestICTStrings.java
 * @brief This class tests a subset of the String class functionality.
 * @version 5.2.2016
 * @author j fitzgerald
 */
public class TestICTStrings
{
    /**
     * Compares two string for equality.
     */
    public static void test_isEqual()
    {
        String s1 = "ICTSkills Studio";
        String s2 = "ictskills studio";
        System.out.println("isEqual:  "+ICTStrings.isEqual(s1, s1));
    }

    /**
     * Compares two string for equality, ignorning case.
     */    
    public static void test_isEqualIgnoreCase()
    {
        String s1 = "ICTSkills Studio";
        String s2 = "ictskills studio";
        System.out.println("isEqualIgnoreCase:  "+ICTStrings.isEqual(s1, s1));
    }

    /**
     * Tests if a string is a prefix of another string.
     */
    public static void test_hasPrefix()
    {
        String s1 = "ICTSkills Studio";
        String prefix = "ICT";
        System.out.println("hasPrefix:  "+ICTStrings.hasPrefix(s1, prefix));
    }

    /**
     * Calculates the combined length of two strings.
     */
    public static void test_length()
    {
        String s1 = "ICTSkills ";
        String s2 = "Studio";
        System.out.println("length:  "+ICTStrings.length(s1, s2));
    }

    /**
     * Converts a string to upper case.
     */
    public static void test_toUpperCase()
    {
        String s1 = "ictskills studio";
        System.out.println("toUpper:  "+ICTStrings.toUpper(s1));
    }

    /**
     * Checks if a string ends with a given string.
     */
    public static void test_endsWith()
    {
        String s1 = "ictskills studio";
        System.out.println("String " + s1 + " ends with udio? " + ICTStrings.endsWith(s1, "udio"));
    }

    /**
     * Tests if a string is a substring of another string.
     */
    public static void test_subString()
    {
        String s1 = "Able was I";
        int startIndex = 2;
        int endIndex =  8;
        System.out.println("subString:  "+ICTStrings.subString(s1, startIndex, endIndex));
    }

    /**
     * Reverses a string using the StringBuilder class.
     */
    public static void test_reverse_1()
    {
        String s1 = "Able was I ere I saw elba";
        System.out.println("reverse:  "+ICTStrings.reverse_1(s1));
    }

    /**
     * Reverses a string by manipulating individual characters in that string.
     */
    public static void test_reverse_2()
    {
        String s1 = "Able was I ere I saw elba";
        System.out.println("reverse:  "+ICTStrings.reverse_2(s1));
    }

    /**
     * Reverses a string using the StringBuffer class.
     */
    public static void test_reverse_3()
    {
        String s1 = "Able was I ere I saw elba";
        System.out.println("reverse:  "+ICTStrings.reverse_3(s1));
    }

    /**
     * Tests if a string is a palindrome.
     */
    public static void test_isPalindrome()
    {
        String s = "No lemon, no melon";
        boolean b = ICTStrings.isPalindrome(s);
        if (b)
        {
            System.out.println(s + " is a palindrome");
        }
        else
        {
            System.out.println(s + " is not a palindrome");
        }
    }

    /**
     * Tests if a string is a palindrome by traversing the first half only of
     * the string and comparing each successive character with its corresponding
     * character in the second half.
     */
    public static void test_isPalindrome2()
    {
        String s = "No lemon, no melon";
        boolean b = ICTStrings.isPalindrome2(s);
        if (b)
        {
            System.out.println(s + " is a palindrome");
        }
        else
        {
            System.out.println(s + " is not a palindrome");
        }
    }

    /**
     * This method executes all other methods in this class in a batch.
     */
    public static void test_all()
    {
        test_isEqual();
        test_isEqualIgnoreCase();
        test_hasPrefix();
        test_length();
        test_toUpperCase();
        test_endsWith();
        test_subString();
        test_reverse_1();
        test_reverse_2();
        test_reverse_3();
        test_isPalindrome();
        test_isPalindrome2();
    }
}
