public class ClockDisplay
{

    private NumberDisplay days;
    private NumberDisplay hours;
    private NumberDisplay minutes;
    private NumberDisplay seconds;

    private String displayTime;

    public ClockDisplay()
    {
        days      = new NumberDisplay(365);
        hours     = new NumberDisplay(24);
        minutes   = new NumberDisplay(60);
        seconds   = new NumberDisplay(60);
    }

    public void updateDisplay()
    {

        this.displayTime = days.display() + ":" + hours.display() + ":" + minutes.display() + ":" + seconds.display();
    }

    public void resetSeconds(int value)
    {
        seconds.setValue(value);
    }    

    public void resetMinutes(int value)
    {
        minutes.setValue(value);
    }

    public void resetHours(int value)
    {
        hours.setValue(value);
    }

    public void resetDays(int value)
    {
        days.setValue(value);
    }

    public void timeTick()
    {
        seconds.incrementValue();
        //when seconds reaches 60 it's time to reset seconds to zero and increment minutes
        if(seconds.getValue() == 0)
        {   
            minutes.incrementValue();
            //when minutes value reaches 60 it's time to reset minutes to zero and increment hours
            if(minutes.getValue() == 0)
            {
                hours.incrementValue();
                if (hours.getValue() == 0)
                {
                    days.incrementValue();
                }
            }
        }
        updateDisplay();
    }

    public String getTime()
    {
        return displayTime;
    }
}