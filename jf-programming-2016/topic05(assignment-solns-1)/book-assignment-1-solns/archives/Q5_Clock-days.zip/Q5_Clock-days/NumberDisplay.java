    
/**
 * Write a description of class NumberDisplay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NumberDisplay
{
    private int limit;
    private int value;
    
    public NumberDisplay(int limit)
    {
        this.limit = limit;
        this.value = 0;
    }
    
    public int getValue()
    {
        return value;
    }
    
    public void incrementValue()
    {
        value = (value + 1) % limit;
    }
    
    public void setValue(int value)
    {
       if(inRange(value)) 
       {
           this.value = value;
       }
    }
    
    private boolean inRange(int value)
    {
        return value >= 0 && value < limit;
    }
    
    /*
     * Print leading zeroes, example 02 seconds, 021 days
     */
    public String display()
    {

        if ((limit == 60 || limit == 24) && value < 10)  // seconds, minutes or hours
        {
            return "0" + value;
        }
        else if (limit == 365 && value < 10) // days
        {
            return "00" + value;
        }
        else if (limit == 365 && value >= 10 && value < 100) // days
        {
            return "0" + value;
        }
        else
        {
            return Integer.toString(value);
        }
    }
    
}
