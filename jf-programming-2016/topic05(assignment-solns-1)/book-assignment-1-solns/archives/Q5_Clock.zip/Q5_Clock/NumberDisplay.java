
/**
 * Write a description of class NumberDisplay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NumberDisplay
{
    private int limit;
    private int value;
    
    public NumberDisplay(int limit)
    {
        this.limit = limit;
        this.value = 0;
    }
    
    public int getValue()
    {
        return value;
    }
    
    public void incrementValue()
    {
        value = (value + 1) % limit;
    }
    
    public void setValue(int value)
    {
       if(inRange(value)) 
       {
           this.value = value;
       }
    }
    
    private boolean inRange(int value)
    {
        return value >= 0 && value < limit;
    }
    
    public String display()
    {

        //add a leading zero where necessary
        if(value < 10)
        {
            return "0" + value;
        }
        else
        {
            return Integer.toString(value);
        }
    }
    
}
