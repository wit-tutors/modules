public class VigenereCipher
{

    /**
     * Constructs a new VigenereCipher object.
     */
    public VigenereCipher()
    {}

    /**
     * Generates the Vigenere Table.
     */
    public static void generateVigenereTable()
    {

    }

    /**
     * Use the keyword to generate a key.
     * Key length is the same as the length of the plain text.
     * The key comprises repeating keyword. 
     * The last keyword in the key is truncated if necessary.
     *
     * @param keyLength The number of characters in the key.
     * @param plainText The plain text for which a key will be generated.
     * @return The key for use in encrypting a message whose length matches the key length.
     */
    public String generateKey(String keyword, int keyLength)
    {
        return "";
    }

    /**
     * Encrypts plain text (message text) under the key using the Vigenere Table.
     * 
     * @param plainText The plain text (message text) to be encrypted
     * @param key The key under which the plain text is encrypted
     * @return The cipher text created by encrypting the plaintext under the generated key.
     */
    public String encrypt(String key, String plainText)
    {
        return "";
    }

    /**
     * Decrypts cipher text under the key using the Vigenere Table.
     * 
     * @param key The key under which the cipher text is deccrypted
     * @param cipherText The cipher text to be decrypted.
     * @return The plain text obtained by decrypting the cipher text under the generated key.
     */

    public String decrypt(String key, String cipherText)
    {

        return "";
    }

    /**
     * Print the vigenere table.
     * 
     */
    public void printVigenereTable()
    {

    }

    /**
     * Print the key.
     * 
     * @param key The key used for encryption and decryption.
     */
    public void printKey(String key)
    {

    }

    /**
     * Print the plain text (message text).
     * 
     * @param plainText The plain text (message text).
     */
    public void printMessage(String plainText)
    {

    }

    /**
     * Print the cipher text.
     * 
     * @param cipherText The encrypted message.
     */
    public void printCipher(String cipherText)
    {

    }

    /**
     * Test method by: 
     *  Generating and printing Vigenere Table,
     *  Generating the key using the keyword,
     *  Encrypting a message (plain text),
     *  Decrypting the cipher text.
     *  Printing the table, key, message, ciphertext & decrypted ciphertext.
     */
    public void testVigenere()
    {

        generateVigenereTable();

        String messageText = "MICHIGANTECHNOLOGICALUNIVERSITY";
        String key = generateKey("HOUGHTON", messageText.length());
        String cipherText = encrypt(key, messageText);
        String decrypted = decrypt(key, cipherText);

        printVigenereTable();
        printKey(key);
        printMessage(messageText);
        printCipher(cipherText);
        printMessage(decrypted);
    }
}