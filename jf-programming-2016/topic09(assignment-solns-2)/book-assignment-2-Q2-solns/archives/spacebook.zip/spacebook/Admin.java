public class Admin
{
    public static void testAll()
    {
        TestSpacebook.testAll();
        TestMessaging.testAll();
    }
}
