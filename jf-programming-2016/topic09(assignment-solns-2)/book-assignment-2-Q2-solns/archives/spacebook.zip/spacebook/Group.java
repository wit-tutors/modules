import java.util.ArrayList;

public class Group
{
    String groupName;

    ArrayList<User> members = new ArrayList<>();

    public Group(String groupName)
    {
        this.groupName = groupName;
    }

    public void addGroupMember(User user)
    {
        members.add(user);

    }
    public void broadcastMessage(Message message)
    {
        for(User user : members)
        {
            user.inbox.add(message);
        }
    }

    private String groupList()
    {
        String names = "";
        for(User user : members)
        {
            names += user.firstName + "\n";
        }
        return names;
    }
    @Override
    public String toString() {
        return "GroupName=" + groupName + "\n" + groupList();
    }

}