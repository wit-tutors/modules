public class Measure
{

    /**
     * @return largest surface area from the array of cones
     */
    public static double maximum(Cone[] cone)
    {
        double maxSurfaceArea = 0;
        //...
        return maxSurfaceArea;
    }
    
    /**
     * @return  the area of the largest circle in the array
     */
    public static double maximum(Circle[] circle)
    {
        double maxArea = 0;
        //...
        return maxArea;
    }
    
    /**
     * @return the longest perimeter from the array of rectangles
     */
    public static double maximum(Rectangle[] rectangle)
    {
        double maximumPerimeter = 0;
        //..
        return maximumPerimeter;
    }
}