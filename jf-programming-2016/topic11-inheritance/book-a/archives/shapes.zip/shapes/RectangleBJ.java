  

import java.awt.*;

public class RectangleBJ
{
    private int xSideLength;
    private int ySideLength;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    public RectangleBJ()
    {
        xSideLength = 60;
        ySideLength = 30;
        xPosition = 60;
        yPosition = 50;
        color = "red";
        isVisible = false;
        setState(60, 30, 60, 50, "red"); 
    }

    public RectangleBJ(int xSideLength, int ySideLength, int xPosition, int yPosition, String color)
    {
        setState(xSideLength, ySideLength, xPosition, yPosition, color);
    }

    public void setState(int xSideLength, int ySideLength, int xPosition, int yPosition, String color)
    {
        this.xSideLength = xSideLength;
        this.ySideLength = ySideLength;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.color = color;
        isVisible = true;
    }

    public void makeVisible()
    {
        isVisible = true;
        draw();
    }

    public void makeInvisible()
    {
        erase();
        isVisible = false;
    }

    public void moveTo(int x, int y)
    {
        xPosition = x;
        yPosition = y;
        makeVisible();
    }

    public void moveRight()
    {
        moveHorizontal(20);
    }

    public void moveLeft()
    {
        moveHorizontal(-20);
    }

    public void moveUp()
    {
        moveVertical(-20);
    }

    public void moveDown()
    {
        moveVertical(20);
    }

    public void moveHorizontal(int distance)
    {
        erase();
        xPosition += distance;
        draw();
    }

    public void moveVertical(int distance)
    {
        erase();
        yPosition += distance;
        draw();
    }
    
    
    public void changeSize(int xSideLength, int ySideLength)
    {
        if(xSideLength > 0 && ySideLength > 0) 
        {
            erase();
            this.xSideLength = xSideLength;
            this.ySideLength = ySideLength;
            draw();
        }
        else
        {
            System.out.println("Enter positive dimensions");
        }

    }

    public void changeColor(String color)
    {
        this.color = color;
        draw();
    }

    private void draw()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                    new Rectangle(xPosition, yPosition, xSideLength, ySideLength));
            canvas.wait(10);
        }
    }

    private void erase()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}