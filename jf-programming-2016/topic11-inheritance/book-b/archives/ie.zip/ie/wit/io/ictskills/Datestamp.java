package ie.wit.io.ictskills;

/**
 * @author  jfitzgerald
 * @version 2014-06-05
 * @brief   contains a static method to return the current date and time in a string 
 */
import ie.wit.io.ictskills.StdOut;

import java.util.*;
import java.text.SimpleDateFormat;

public class Datestamp
{

  /**
   * Formats the current date and time
   * @return formatted string containing time-date stamp as yyyy-MM-dd- HH:mm:ss
   */
  public static String timestamp()
  {
    SimpleDateFormat localDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    return localDateFormat.format( new Date());
  }
  
  /**
   * main test method
   * @param args
   */
  public static void main(String[] args)
  {
    StdOut.println(timestamp());   
  }
}
