package factorial;

 class Factorial
{
  int n_factorial = 1;
  
  public void factorial_iter(int n)
  {
    if (n == 0) 
    {
      n_factorial = 1;
      return;
    }
    for (int i = 1; i <= n; i +=1) 
    {
      n_factorial *= i;
    }
  }

  public void factorial_recurse(int n)
  {
    if (n == 0)
    {
      return;
    }
    else
    {
      n_factorial *= n;
      factorial_recurse(n-1);
    }  
  }
  
  void iterate()
  {
    for (int i = 0; i <= 6; i += 1)
    {
      factorial_iter(i);
      System.out.println("Factorial " + i + " is " + n_factorial);
      n_factorial = 1; //reset for next iteration
    }
  }
  
  void recurse()
  {
    for (int i = 0; i <= 6; i += 1)
    {
      factorial_recurse(i);
      System.out.println("Factorial " + i + " is " + n_factorial);
      n_factorial = 1; //reset for next iteration
    }
  }
  
  public static void main(String[] args)
  {
    Factorial factorial = new Factorial();
    System.out.println("Factorial using iteration");
    factorial.iterate();
    System.out.println("\nFactorial using recursion");
    factorial.recurse();
  }
}
