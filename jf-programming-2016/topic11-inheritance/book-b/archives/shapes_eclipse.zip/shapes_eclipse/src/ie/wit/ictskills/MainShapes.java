package ie.wit.ictskills;

public class MainShapes
{

  public static void main(String[] args)
  {
    Circle circle = new Circle(100, 0, 0, "yellow");
    circle.makeVisible();
    Rectangle rectangle = new Rectangle();
    rectangle.makeVisible();
    Triangle triangle = new Triangle();
    triangle.makeVisible();
  }

}
