package ie.wit.spacebook;

public class Friendship
{
    User sourceUser;
    User targetUser;
    
    public Friendship(User sourceUser, User targetUser)
    {
        this.sourceUser = sourceUser;
        this.targetUser = targetUser;
    }
}
