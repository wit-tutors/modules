package ie.wit.spacebook;

import java.util.ArrayList;
import java.util.Iterator;

public class User
{
    String firstName;
    String lastName;
    int age;
    String nationality;
    String email;
    String password;
    
    ArrayList<Friendship> friendships   = new ArrayList<>();
    ArrayList<Message> inbox            = new ArrayList<>();
    ArrayList<Message> outbox           = new ArrayList<>(); 
    
    public User(String firstName, String lastName, int age, String nationality, String email, String password)
    {
        change(firstName, lastName, age, nationality, email, password);
    }
 
        
    public User(String firstName, String lastName, String email, String password)
    {
        this.firstName  = firstName;
        this.lastName   = lastName;
        this.email      = email;
        this.password   = password;
    }
    
    
    public void broadcastMessage(String messageText)
    {
        for(Friendship f : friendships)
        {
            Message message = new Message(this, f.targetUser, messageText);
            outbox.add(message);
            f.targetUser.inbox.add(message);
        }
    }
    
    public void change(String firstName, String lastName, int age, String nationality, String email, String password)
    {
        this.firstName  = firstName;
        this.lastName   = lastName;
        this.age        = age;
        this.nationality= nationality;
        this.email      = email;
        this.password   = password;        
    }
    
    public void sendMessage(User to, String messageText)
    {
        Message message = new Message(this, to, messageText);
        outbox.add(message);
        to.inbox.add(message);
    }
 
    public void displayOutbox()
    {
      for(Message msg : outbox)
      {
        msg.displayMessage();
      }
    }
    
    public void displayInbox()
    {
      for(Message msg : inbox)
      {
        msg.displayMessage();
      }
    }
    public void befriend(User friend)
    {
        if(!(friend == this))
        {
            Friendship friendship = new Friendship(this, friend);
            friendships.add(friendship);
        }
        else
        {
            System.out.println("Opps! You seem to have made a mistake in attempting to befriend yourself");
        }
    }
  
    public void unfriendAll()
    {
        for(int i = friendships.size() - 1; i >= 0; i -= 1)
        { 
            friendships.remove(i);
        }
    }
    
        public void unfriendAll2()
    {
        Iterator<Friendship> it = friendships.iterator();
        while(it.hasNext())
        {
            it.next();
            it.remove();
        }
    }
    
    public void unfriendAll3()
    {
        for(int i = 0; i < friendships.size(); i ++)
        {
            System.out.println("i "+i+" size "+friendships.size());
            friendships.remove(i);
        }
        System.out.println();
        System.out.println("Number of elements remaining friendships list is: "+friendships.size());
        for(int i = 0; i < friendships.size(); i ++)
        {
            Friendship f = friendships.get(i);
            System.out.println(f.sourceUser.firstName + "'s friend is "+f.targetUser.firstName); 
        }
    }
    
    public void unfriend(User friend)
    {
        for(Friendship friendship : friendships)
        {
            if(friendship.targetUser == friend)
            {
                friendships.remove(friendship);
                return;
            }
        }
    }
  
    public void displayFriends() 
    {
        if(friendships.isEmpty())
        {
            System.out.println("Unfortunately you have no friends");
        }
        for(Friendship friendship : friendships)
        {
            System.out.println("My friend is "+friendship.targetUser.firstName);
        }
    }
  }