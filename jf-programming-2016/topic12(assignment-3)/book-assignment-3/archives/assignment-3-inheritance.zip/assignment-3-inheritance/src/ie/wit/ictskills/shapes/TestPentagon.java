package ie.wit.ictskills.shapes;

public class TestPentagon {

	public static void main(String[] args) 
	{
	// TODO Task 3: Display 4 cascaded Pentagons differently colored shapes.	

	}

}
