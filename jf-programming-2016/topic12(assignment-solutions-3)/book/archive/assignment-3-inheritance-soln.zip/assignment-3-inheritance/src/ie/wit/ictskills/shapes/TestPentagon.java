package ie.wit.ictskills.shapes;

import java.util.ArrayList;

// TODO Task 4: Display 4 cascaded Pentagons differently colored shapes.	

public class TestPentagon
{
    public static void main(String[] args)
    {
        ArrayList<Shapes> shapes = new ArrayList<>();
 
        shapes.add(new Pentagon(30, 60, 30, "red"));
        shapes.add(new Pentagon(40, 90, 50, "blue"));
        shapes.add(new Pentagon(50, 120, 70, "green"));
        shapes.add(new Pentagon(60, 150, 90, "black"));   
        
        for(Shapes shape : shapes)
        {
            shape.makeVisible();
        }
    }
}
