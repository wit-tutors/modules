package util;
// TODO Task 7: Implement method Util.maximum
import ie.wit.ictskills.shapes.Measurable;

import java.util.ArrayList;

public class Util 
{
	/**
	 * Measureable interface contains the method double perimeter().
	 * The method maximum here evalutates the single value representing the largest
	 * perimeter discovered in the list of Measurable objects.
	 *
	 * @param object The list of objects whose classes implement the interface Measurable
	 * @return Returns the largest perimeter discovered among entire list objects.
	 */
	static public double maximum(ArrayList<Measurable> object) 
	{
		{
			double max = object.get(0).perimeter();
			for (int i = 1; i < object.size(); i += 1) 
			{
				double val = object.get(i).perimeter();
				max = val > max ? val : max;
			}
			return max;
		}
	}
}
