package controllers;

import java.util.ArrayList;
import java.util.Collections;

import utils.MessageDateComparator;
import utils.MessageFromComparator;
import views.HomeView;
import models.Friendship;
import models.Message;
import models.User;

public class Home
{ 
  /**
   * Dispatches a list of messages in the user's inbox to HomeView for rendering
   * This method simulates that activated in the web version of spaceboook Home page responding to BY DATE button press
   * Note that the method HomeView.index(User, ArrayList<Message>) could have been condensed
   * to HomeView.index(User) since the reference to outbox is available from within the User object. The more verbose 
   * version of the method has been chosen to preserve similarity with the equivalent Play method.
   * A similar approach has been adopted with other view methods.
   * 
   * @param user simulates the logged-in user
   */
  public static void index(User user)
  {
    HomeView.index(user, user.inbox);
  }
  
  /**
   * Sort a specific user's inbox.
   * Invoke views home to display sorted list messages
   * 
   * @param user the user whose message inbox will be displayed grouped by user.
   * 
   */
  public static void byUser(User user)
  {
    ArrayList<Message> inbox = new ArrayList<Message>(user.inbox);
    
    Collections.sort(inbox, new MessageFromComparator());
    HomeView.byUser(user, inbox);
  }
  
  /**
   * A conversation between 2 users comprises a list of messages ordered time-wise.
   * A user has a list of friendships and each friendship has a reference to one of that user's friends
   * This method creates a list of conversations between a user and all its friends
   * Thus a conversation comprises a list of time-sorted messages 
   * The conversations reference therefore comprises a list of a list of messages.
   * 
   * @param user the user that initiates the conversation 
   */
  public static void byConversation(User user)
  {  

    ArrayList<ArrayList<Message>> conversations = new ArrayList<ArrayList<Message>>();          
    for (Friendship friendship : user.friendships)
    {
      User friend = friendship.targetUser;
      ArrayList <Message> conversation = getConversation (user, friend);
      conversations.add(conversation);
    }
    HomeView.byConversation(user, conversations);
  }
  
/**
 * Generates a list of messages between two users.
 * The list is sorted by reference to time. 
 * A message object contains an instance of a time object
 * Thus, the list comprises a conversation between the two users.
 * 
 * @param user the user who initiates the conversation
 * @param friend the user with whom the initiator is having a conversation
 * @return the list of messages which makes up the conversation
 */
  static ArrayList<Message> getConversation (User user, User friend)
  {
    ArrayList <Message> conversation = new ArrayList<Message>();
    for (Message message : user.outbox)
    {
      if (message.to == friend)
      {
        conversation.add(message);
      }
    }
    for(Message message : user.inbox)
    {
      if (message.from == friend)
      {
        conversation.add(message);
      }
    }
    Collections.sort(conversation, new MessageDateComparator());
    return conversation;
  }
}
