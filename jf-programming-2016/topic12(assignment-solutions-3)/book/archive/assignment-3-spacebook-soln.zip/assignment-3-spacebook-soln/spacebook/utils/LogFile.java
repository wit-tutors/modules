package utils;
/**
 * @file    LogFile.java
 * @brief   This class has functionality that facilitates writing to and reading 
 * from file on disk. 
 * Class also has method to sort logs in ascending alphanumeric order
 * @version 1.0 April 1, 2014
 * @author  jfitzgerald
 */

import java.util.ArrayList;
import java.util.Collections;
import ie.wit.io.ictskills.In;
import ie.wit.io.ictskills.Out;

public class LogFile
{
  /**
   * Read a file and create array list of individual lines
   * 
   * @return the arraylist of individual file lines
   */
  public ArrayList<String> fileToList(String filename) throws Exception
  {
    ArrayList<String> logs = new ArrayList<>();
    System.out.println("------------------------------------------");
    System.out.println("Sorted message logs;");
    System.out.println("------------------------------------------");
    In in = new In(filename);
    while (!in.isEmpty())
    {
      String s = in.readLine();
      logs.add(s);
    }
    return logs;
  }

  /**
   * Sorts a copy of the array of strings using bespoke comparator
   */
  public void sort(ArrayList<String> logs)
  {
    ArrayList<String> copyLogs = new ArrayList<String>(logs);
    System.out.println("------------------------------------------");
    System.out.println("Sorted message logs;");
    System.out.println("------------------------------------------");
    Collections.sort(copyLogs, new AlphanumComparator());
    for (String s : copyLogs)
    {
      System.out.println(s);
    }
  }

  /**
   * Append string data to end of file without changing existing file content,
   * creating the file if it does not already exist.
   * 
   * @param data
   *          the string to append to file
   */
  public static void append(String data, String filename)
  {
    Out.append(data, filename);
  }
  
  public static void main(String[] args)
  {
    try
    {
      LogFile logfile = new LogFile();
      ArrayList<String> logs = logfile.fileToList("spacebook-messagelog.txt");
      logfile.sort(logs);
    }
    catch (Exception e)
    {
      e.getStackTrace();
    }
  }
}
