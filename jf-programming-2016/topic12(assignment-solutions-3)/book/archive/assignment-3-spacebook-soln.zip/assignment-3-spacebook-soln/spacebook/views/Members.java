package views;
import java.util.ArrayList;
import models.User;

public class Members
{
  /**
   * Display friends and messages
   * 
   * @param users list of users
   */
  public static void index(ArrayList<User> users)
  {
    displayUsers(users);
  }
  
  private static void displayUsers(ArrayList<User> users)
  {
    for(User user : users)
    {
      System.out.println(user);
    }
  }
 
}
