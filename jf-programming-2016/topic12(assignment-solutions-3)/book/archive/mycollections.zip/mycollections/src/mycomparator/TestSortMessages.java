package mycomparator;

import java.util.ArrayList;

import utils.MessageTextComparator;
import utils.MyCollections_v0;
import utils.MyCollections_v1;
import utils.UserBankBalanceComparator;


public class TestSortMessages
{
  private static ArrayList<User> users = new ArrayList<>();
  private static ArrayList<Message> messages = new ArrayList<>();
  
  public static void initializeUsers()
  {
    users.add(new User("homer"    , 400));
    users.add(new User("lisa"     , 100));
    users.add(new User("bart"     , 200));
    users.add(new User("marge"    , 300));
    users.add(new User("barney"   , 500));
    users.add(new User("aristotle", 600));
    users.add(new User("atkins"   , 700));
    users.add(new User("jasper"   , 800));
    users.add(new User("bobarela" , 900));
    users.add(new User("ling"     , 950));
    users.add(new User("patty"    , 990));
  }
  
 
  
  public static void initializeMessages()
  {
    messages.add(new Message(users.get(3), users.get(0), "Where are You off to?"              ));
    messages.add(new Message(users.get(0), users.get(3), "I'm off to the pub?"                ));
    messages.add(new Message(users.get(3), users.get(0), "Why are you not at work?"           ));
    messages.add(new Message(users.get(3), users.get(0), "Why are you going to the pub?"      ));
    messages.add(new Message(users.get(0), users.get(3), "Doh!"                               ));
    messages.add(new Message(users.get(3), users.get(0), "don't be late!"                     ));
    messages.add(new Message(users.get(3), users.get(0), "explain Yourself?"                  ));
    messages.add(new Message(users.get(0), users.get(3), "I am working!?"                     ));
    messages.add(new Message(users.get(3), users.get(2), "Get your dad from the pub please"   ));

  }

  public static void print(ArrayList<Message> messages)
  {
    for (Message message : messages)
    {
      System.out.println(message);
    }
  }
  
  public static void sortByMessageDate()
  {
//    MyCollections_v0<Message> collection = new MyCollections_v0<Message>();
//    collection.sort(messages, new MessageTextComparator());
    MyCollections_v1.sort(messages, new MessageTextComparator());
  }

  
  public static void main(String[] args)
  {
    initializeUsers();
    initializeMessages();
    System.out.println("---------------------------------");   
    System.out.println("Unsorted messages");
    System.out.println("---------------------------------");
    print(messages);
    sortByMessageDate();
    System.out.println("---------------------------------");
    System.out.println("Users sorted by message text");
    System.out.println("---------------------------------");
    print(messages);
  }

}
