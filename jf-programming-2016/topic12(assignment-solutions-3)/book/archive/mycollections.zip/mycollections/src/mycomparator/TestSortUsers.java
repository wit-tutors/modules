package mycomparator;

import java.util.ArrayList;

import utils.MyCollections_v0;
import utils.UserNameComparator;
import utils.UserBankBalanceComparator;


public class TestSortUsers
{

  private static ArrayList<User> users = new ArrayList<>();
  
  public static void initialize()
  {
    users.add(new User("homer"    , 400));
    users.add(new User("lisa"     , 100));
    users.add(new User("bart"     , 200));
    users.add(new User("marge"    , 300));
    users.add(new User("barney"   , 500));
    users.add(new User("aristotle", 600));
    users.add(new User("atkins"   , 700));
    users.add(new User("jasper"   , 800));
    users.add(new User("bobarela" , 900));
    users.add(new User("ling"     , 950));
    users.add(new User("patty"    , 990));
  }

  public static void print(ArrayList<User> users)
  {
    for (User user : users)
    {
      System.out.format("%10s has bank balance %d\n", user.name, user.bankBalance);
    }
  }
  
  public static void sortByUserName()
  {
    MyCollections_v0<User> collection = new MyCollections_v0<User>();
    collection.sort(users, new UserNameComparator());
  }

  public static void sortByUserBankBalance()
  {
    MyCollections_v0<User> collection = new MyCollections_v0<User>();
    collection.sort(users, new UserBankBalanceComparator());
  }
  
  public static void main(String[] args)
  {
    initialize();
    System.out.println("---------------------------------");   
    System.out.println("Unsorted users");
    System.out.println("---------------------------------");
    print(users);
    sortByUserName();
    System.out.println("---------------------------------");
    System.out.println("Users sorted by user name");
    System.out.println("---------------------------------");
    print(users);
    
    sortByUserBankBalance();
    System.out.println("---------------------------------");
    System.out.println("Users sorted by bank balance");
    System.out.println("---------------------------------");
    print(users);
  }

}
