package mycomparator;

public class User
{
  public String name;
  public int bankBalance;

  public User(String name, int bankBalance)
  {
    this.name = name;
    this.bankBalance = bankBalance;
  }
}
