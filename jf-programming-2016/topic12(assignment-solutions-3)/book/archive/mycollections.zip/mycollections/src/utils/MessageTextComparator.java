package utils;

import java.util.Comparator;

import mycomparator.Message;

public class MessageTextComparator implements Comparator<Message>
{
  @Override
  public int compare(Message a, Message b)
  {
    return a.messageText.compareToIgnoreCase(b.messageText);
  }
}
