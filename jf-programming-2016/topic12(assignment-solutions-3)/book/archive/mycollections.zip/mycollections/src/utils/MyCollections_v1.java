package utils;

/**
 * @file MyCollections.java
 * @brief Uses merge sort algorithm to sort an ArrayList of generic objects
 * @version 20 May 2015
 * @author  Based on mergesort algorithm by Sedgewick et al.
 * @author jfitzgerald : converted for generic use.
 */

import java.util.ArrayList;
import java.util.Comparator;

public class MyCollections_v1<T>
{
  public static <T> void sort(ArrayList<T> a, Comparator<T> c)
  { 

    //ArrayList<T> aux = (ArrayList<T>) a.clone();
    // following initialization of aux is a hack: should use above line but this dependent on
    // clone implemented in all T, example User, Message and so on.
    int N = a.size();
    ArrayList<T> aux = new ArrayList<>(); 
    for (int i = 0; i < N; i +=1)
      aux.add(null);
    

    for (int size = 1; size < N; size = size + size)
      for (int lo = 0; lo < N - size; lo += size + size)
        merge(aux, a, lo, lo + size - 1,
            Math.min(lo + size + size - 1, N - 1), c);
  
  }
  
  private static <T> void merge(ArrayList<T> aux, ArrayList<T> a, int lo, int mid, int hi, Comparator<T> c) 
  {
    for (int k = lo; k <= hi; k++)
      aux.set(k, a.get(k));

    int i = lo;
    int j = mid + 1;
    for (int k = lo; k <= hi; k++)
    {
      if (i > mid)                                          a.set(k, aux.get(j++));
      else if (j > hi)                                      a.set(k, aux.get(i++));
      else if (c.compare(aux.get(j), aux.get(i)) < 0)       a.set(k, aux.get(j++));
      else                                                  a.set(k, aux.get(i++));
    }
  }
  
}
