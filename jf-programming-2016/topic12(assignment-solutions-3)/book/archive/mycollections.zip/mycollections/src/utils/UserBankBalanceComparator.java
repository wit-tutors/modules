package utils;

import java.util.Comparator;

import mycomparator.User;

public class UserBankBalanceComparator implements Comparator<User>
{

  @Override
  public int compare(User o1, User o2)
  {
    return Integer.compare(o1.bankBalance, o2.bankBalance);
  }
}
