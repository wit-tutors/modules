package utils2;

import java.util.ArrayList;
import mycomparator.User;
/**
 * @file MergeSortBids.java
 * @brief Uses merge sort algorithm to sort an ArrayList of User objects
 * @version 28 April 2015
 * @author jfitzgerald
 */
public class MergeSort
{
	public static ArrayList<User> aux;

	private static void merge(ArrayList<User> a, int lo, int mid, int hi) 
	{
		for (int k = lo; k <= hi; k++)
			aux.set(k, a.get(k));

		int i = lo;
		int j = mid + 1;
		for (int k = lo; k <= hi; k++)
		{
			if (i > mid)                                     			a.set(k, aux.get(j++));
			else if (j > hi)                                 			a.set(k, aux.get(i++));
			else if (compareTo(aux.get(j), aux.get(i)) < 0)       a.set(k, aux.get(j++));
			else                                             			a.set(k, aux.get(i++));
		}
	}

	public static void sort(ArrayList<User> a) 
	{
		int N = a.size();

		// initialize aux arraylist
		aux = new ArrayList<>(); 
		for (int i = 0; i < N; i +=1)
			aux.add(null);

		for (int size = 1; size < N; size = size + size)
			for (int lo = 0; lo < N - size; lo += size + size)
				merge(a, lo, lo + size - 1,
						Math.min(lo + size + size - 1, N - 1));
	}

	 static int compareTo(User a, User b)
	{
		return a.name.compareTo(b.name);
	}
}