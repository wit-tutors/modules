package utils2;

import java.util.Comparator;

import mycomparator.User;


public class MyComparator implements Comparator<User>
{

	@Override
	public int compare(User o1, User o2) {
		// TODO Auto-generated method stub
		return 0;
	}
}
