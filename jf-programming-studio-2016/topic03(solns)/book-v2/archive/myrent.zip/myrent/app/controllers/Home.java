package controllers;


import play.mvc.*;

public class Home extends Controller {

    public static void index() {
        render();
    }
}