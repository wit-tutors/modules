package controllers;

import play.mvc.Controller;

public class Acknowledgement extends Controller
{
  public static void index()
  {
    render();
  }
}
