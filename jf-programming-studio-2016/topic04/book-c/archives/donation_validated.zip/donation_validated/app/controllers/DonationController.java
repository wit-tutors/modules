package controllers;

import java.util.ArrayList;
import java.util.List;

import play.Logger;
import play.mvc.Controller;


public class DonationController extends Controller 
{

    public static void index()
    {
        String donationprogress = percentDonationTargetReached();
        render(donationprogress);
    }

    private static String percentDonationTargetReached()
    {
      return "70";
    }
    
    public static void donate(long amountDonated, String methodDonated) 
    {
        Logger.info("amount donated " + amountDonated + " " + "method donated " + methodDonated);
        index();
    }
      
}