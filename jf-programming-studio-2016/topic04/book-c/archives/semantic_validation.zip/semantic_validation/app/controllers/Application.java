package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Application extends Controller {

    public static void index() {
        render();
    }
    
    public static void txd(User user)
    {
      Logger.info("Application.rxd: user.name " + user.name);
      Logger.info("Application.rxd: user.gender " + user.gender);
      Logger.info("Application.rxd: user.username " + user.username);
      Logger.info("Application.rxd: user.password " + user.password);
      Logger.info("Application.rxd: user.terms " + user.terms);
     
      user.save();
      index();
    }

}