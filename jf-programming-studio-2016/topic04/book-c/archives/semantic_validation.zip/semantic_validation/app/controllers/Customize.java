package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Customize extends Controller {

    public static void index() {
        render();
    }
    
    public static void txd(String latitude)
    {
      Logger.info("Customize.rxd: latitude is  " + latitude);
     
      index();
    }
}