package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import org.json.simple.JSONObject;

import models.*;

public class DonationController extends Controller {

  /**
   * Use session object to store initial percent target reached of 70.
   */
  public static void index()
  {
      session.put("progressPercent",  70);
      String donationprogress = percentDonationTargetReached();
      render(donationprogress);
  }

  /**
   * @return The percent target reached stored in session object
   */
  private static String percentDonationTargetReached()
  {   
    return session.get("progressPercent");
  }
  
  /**
   * Receive donation data, 
   * increment the percent target reached, 
   * write log entry and 
   * render json objec with progress %
   * 
   * @param amountDonated
   * @param methodDonated
   */
  public static void donate(long amountDonated, String methodDonated) 
  {      
      // For each donation the progressPercent is increased by an arbitrary 10%.
      String progressPercent = percentDonationTargetReached();
      session.put("progressPercent", String.valueOf(Integer.parseInt(progressPercent) + 10));
      // If donationTargetReached exceeds 100, reset it to 100
      if(Integer.parseInt(session.get("progressPercent")) > 100)
      {
        progressPercent = "100";
      }
      
      Logger.info("amount donated " + amountDonated + " " + "method donated " + methodDonated);
      // The purpose of this json object is to act as transport for percent progress destined for progress bar
      // The progressPercent variable is the string representation of the number to be transmitted to the progress bar
      JSONObject obj = new JSONObject();
      obj.put("progress", progressPercent);
      renderJSON(obj);
      
  }

}