
/*
 * Bespoke validation functions introduced.
 * isValidLatitude & isValidLongitude implemented in public/semantic/semantic.js at line 1615.
 * Location at which to inject these methods will may vary depending on semantic version
 * Note: this is a temporary fix, good for development only, not production code.
 * The methods not in the minified semantic js file.
 * Methods would be overwritten in any update of semantic.
 * No existing semantic methods to validate floating point number.
 * Existing method to validate integers inadequate for latitude|longitude.
 * See: http://semantic-ui.com/behaviors/form.html#/examples
 */
$('.ui.form')
  .form({
      'latitude': {
      identifier  : 'latitude',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter latitude in range +85 to -85'
        },        
        {
          type   : 'isValidLatitude',
          prompt : 'Please enter latitude: valid range -85.0 to +85.0'
        }
      ]
    }
  }); 