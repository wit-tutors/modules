$('.ui.dropdown').dropdown();

$('.ui.form')
.form({
	
  amountDonated: {
    identifier: 'amountDonated',
    rules: [{
        type: 'empty',
        prompt: 'Please select an amount to donate'
      }]
  }
},

{
	onSuccess : function() {
	    submitForm();
	    return false; // dropdown remains open following press donate button. progress bar fails on return true. why?
	} 
});


/**
 * store form data in variable named formData
 * post form data
 * on return from ajax call:
 *    check if label div present
 *        if label div present detach it
 *    if response confirms 100% target reached:
 *        recreate div with red label advising target reached
 * dynamically create new label div 
 * Note the outer static div has id === targetReached
 * But inner dynamic div has id === target
 */
function submitForm() {
  var formData = $('.ui.form.segment input').serialize(); 
  $.ajax({
    type: 'POST',
    url: '/donation/donate',
    data: formData,
    success: function(response) 
    {            
      console.log("registration response: % target reached is  " + response.progress);
      if ($('#target').length) // If label present detach it
      {
        $('#target').detach();
      }
      if(response.progress === '100') // Attach label if 100% target reached
      {
        $('#targetReached').append('<div id="target" class="ui red label">Target reached</div>');
      }

		  $('.ui.indicating.progress').progress({
			  percent: response.progress
			});
		  $('#progresslabel').text(response.progress + " % of target achieved to date");

    }
  });
}

