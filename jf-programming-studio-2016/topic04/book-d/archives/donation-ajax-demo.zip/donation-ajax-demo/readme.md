To demo no ajax:
1 Switch to branch ajax-no
2 Login : homer@simpon.com 'secret'
3 Switch to donation page.
4 Make any selections on 2 dropboxes.
5 Donate.
6 Note the page refresh.

To demo ajax.
1 Switch to branch ajax-yes.
2 Repeat above steps 2 to 5 inclusive.
3 Observe absence of page refresh.