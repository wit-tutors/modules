package controllers;

import play.mvc.*;


public class About extends Controller
{
  public static void index()
  {
    render();
  }
}