package controllers;

import play.mvc.*;


public class Contact extends Controller
{
  public static void index()
  {
    render();
  }
}