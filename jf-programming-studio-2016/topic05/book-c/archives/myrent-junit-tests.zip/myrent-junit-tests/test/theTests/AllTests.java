package theTests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ 
  LandlordTenantResidence.class ,
  LandlordTest.class, 
  TenantTest.class,
  ResidenceTest.class, 
  LandlordResidence.class, 
  TenantResidence.class, 

  })
public class AllTests
{
}
