package theTests;

import org.junit.*;

import models.Landlord;
import models.Residence;

import java.util.*;
import play.test.*;
import theTests.*;
import play.*;
import play.jobs.*;
import play.test.*;
/**
 * Create a landlord and a residence
 * Establish entity relationship
 *
 */
public class LandlordResidence extends UnitTest
{

  private Landlord landlord;
  private Residence residence1;
  
  @Before
  public void setup()
  {
    landlord = new Landlord("homer", "simpson", "homer@simpson.com"); 
    landlord.save(); 
    residence1 = new Residence(); 
    landlord.residences.add(residence1);
    residence1.landlord = landlord;
    residence1.save();
    landlord.save();
  }

  @After
  public void teardown()
  {
    deleteLandlordResidences();
    
  }

  private void deleteLandlordResidences()
  {
    List<Residence> residences = Residence.findAll();
    for (int i = 0; i < residences.size(); i += 1) 
    {
      Residence residence = residences.get(0);
      landlord.residences.remove(residence);
      landlord.save();
      residence.delete();
    }
    landlord.delete();
  }
  
  @Test
  public void testEntities()
  {
   
    Landlord homer = Landlord.findByEmail("homer@simpson.com");
    Landlord marge = Landlord.findByEmail("marge@hotmail.com");
    
    // Positive test
    assertEquals(homer.equals(landlord), true);
    // Negative test
    assertNull(marge);
  }
  

}
